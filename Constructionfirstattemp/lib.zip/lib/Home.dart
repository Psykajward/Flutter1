import 'package:constructionfirstattemp/Forget%20password.dart';
import 'package:constructionfirstattemp/Sign%20up.dart';
import 'package:constructionfirstattemp/login.dart';
import 'package:constructionfirstattemp/profile/Updateprofile.dart';
import 'package:constructionfirstattemp/profile/profile.dart';
import 'package:flutter/material.dart';
class Home extends StatefulWidget {
  const Home({Key? key}) : super(key: key);

  @override
  State<Home> createState() => _HomeState();
}
class _HomeState extends State<Home> {
  @override
  int currentIndex = 0;
  List<Widget> widgetList = const[
    Home(),
    UpdateProfile(),
    Loginscrean(),
    profile()
  ];
  final screens = [
    Home(),
    Password(),
    Loginscrean(),
    profile(),
  ];

  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: BottomNavigationBar(
          backgroundColor: Colors.deepPurple,
          selectedItemColor: Colors.white,
          unselectedItemColor: Colors.black,
          showUnselectedLabels: false,
          type: BottomNavigationBarType.fixed,
          currentIndex: currentIndex,
          onTap: (Index) => setState(() => currentIndex = Index),

          items: [
            BottomNavigationBarItem(
              icon: Icon(Icons.home),
              label: 'home',),
            BottomNavigationBarItem(
              icon: Icon(Icons.favorite),
              label: 'Favorite',),
            BottomNavigationBarItem(
              icon: Icon(Icons.chat),
              label: 'Chat',),
            BottomNavigationBarItem(
              icon: Icon(Icons.person),
              label: 'home',),
          ]),
      appBar: AppBar(
        backgroundColor: Colors.deepPurple,
        title: Center(child: Text('Construction')),
        leading: Padding(
          padding:  EdgeInsets.only(left: 10),
          child: GestureDetector(
              onTap: () {
                print('object');
                Navigator.of(context).push(MaterialPageRoute(builder: (context) {
                  return Home();
                }));
              },
              child: Center(child: Text('We Build',style: TextStyle(color: Colors.grey,fontWeight: FontWeight.bold,fontSize: 11),))),
        ),
        actions: <Widget>[
          Padding(
            padding: EdgeInsets.only(right: 20.0),
            child: GestureDetector(
              onTap: () {},
              child: Icon(
                Icons.search,
                size: 26.0,
              ),
            ),
          ),
          Padding(
            padding: EdgeInsets.only(right: 20.0),
            child: GestureDetector(
              onTap: () {},
              child: Icon(Icons.more_vert),
            ),
          ),
        ],
        actionsIconTheme:
        IconThemeData(size: 30, color: Colors.black, opacity: 10.0),
      ),
      body: SafeArea(
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          width: MediaQuery
              .of(context)
              .size
              .width,
          child: SingleChildScrollView(
            child: Column(
              children: <Widget>[
                SafeArea(
                  child: Expanded(child: Column(children: <Widget>[
                    Row(children: <Widget>[ Image.asset(
                      'images/logo3.jpeg', height: 150, width: 150,),
                      Row(children: <Widget>[
                        Image.asset(
                          'images/header.png', height: 200, width: 220,),
                      ])
                    ],)
                  ]),),
                ),
                SizedBox(
                  height: 60,
                ),
                Center(
                  child: Text(
                    'We Build is web site helping people to find work and saving alot alot of opportunites to work and helping engineers who want manpower and providing this manpower easily without too much efforts and this will help to reduce the precentage Unemployment in the countery',
                    style: TextStyle(fontSize: 18),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.zero,
                  child: MaterialButton(
                    color: Colors.black,
                    child: Text(
                      'Get Started',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 15,
                      ),
                    ),
                    shape: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(60),
                    ),
                    onPressed: () {
                      Navigator.of(context)
                          .push(MaterialPageRoute(builder: (context) {
                        return Signup();
                      }));
                    },
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}